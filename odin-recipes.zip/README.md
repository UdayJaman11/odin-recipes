# odin-recipes

This is my first project while learning web development through the Odin Project. I will use my html skill.